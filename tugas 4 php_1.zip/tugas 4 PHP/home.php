<!-- page header -->
<header id="home" class="header">
        <div class="overlay"></div>
        <div class="header-content container">
            <h1 class="header-title">
                <span class="up">HI!</span>
                <span class="down">I Riski Eggy Saputro</span>
            </h1>
            <p class="header-subtitle">FULLSTACK DEVELOPER</p>

            <button class="btn btn-primary">Visit My Works</button>
        </div>
    </header><!-- end of page header -->